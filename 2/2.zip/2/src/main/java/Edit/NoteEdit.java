package Edit;

import model.Note;
import javax.persistence.*;

public class NoteEdit {

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("model.Note");
    EntityManager em = entityManagerFactory.createEntityManager();
    Note note = new Note();

    public void saveNote() {
        this.em.getTransaction().begin();
        this.em.persist(this.note);
        this.em.getTransaction().commit();
        this.em.close();
    }

    public void addNote(String data, String name, String text, String teg, int User_idUser) {
        this.note.setData(data);
        this.note.setName(name);
        this.note.setText(text);
        this.note.setTeg(teg);
        this.note.setUser_idUser(User_idUser);
        this.saveNote();
    }

    public Note getNote(int idnote){
        return em.find(Note.class, idnote);
    }

    public void deleteNote(int idnote){
        em.getTransaction().begin();
        em.remove(getNote(idnote));
        em.getTransaction().commit();
    }

    public void updateNote(int idnote, String data, String name, String text, String teg, int User_idUser) {
        this.note.setIdnote(idnote);
        this.note.setData(data);
        this.note.setName(name);
        this.note.setText(text);
        this.note.setTeg(teg);
        this.note.setUser_idUser(User_idUser);
        em.getTransaction().begin();
        em.merge(note);
        em.getTransaction().commit();
    }
}
