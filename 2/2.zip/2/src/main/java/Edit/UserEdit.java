package Edit;

import model.User;
import javax.persistence.*;

public class UserEdit {
    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("model.Note");
    EntityManager em = entityManagerFactory.createEntityManager();
    User user = new User();

    public void saveUser() {
        this.em.getTransaction().begin();
        this.em.persist(this.user);
        this.em.getTransaction().commit();
        this.em.close();
    }

    public void addUser(String name, String password, String email) {
        this.user.setName(name);
        this.user.setPassword(password);
        this.user.setEmail(email);
        this.saveUser();
    }

    public User getUser(int idUser){
        return em.find(User.class, idUser);
    }

    public void deleteUser(int idUser){
        em.getTransaction().begin();
        em.remove(getUser(idUser));
        em.getTransaction().commit();
    }

    public void updateUser(int idUser, String name, String password, String email) {
        this.user.setIdUser(idUser);
        this.user.setName(name);
        this.user.setPassword(password);
        this.user.setEmail(email);
        em.getTransaction().begin();
        em.merge(user);
        em.getTransaction().commit();
    }
}