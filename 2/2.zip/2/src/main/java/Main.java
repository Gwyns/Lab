import Edit.NoteEdit;
import Edit.UserEdit;

public class Main {
    public static void main(String[] args) {

        UserEdit user = new UserEdit();
        user.addUser("User1", "1234", "useremail");
        user.updateUser(2,"User", "1111", "userrr");
        user.deleteUser(3);

        NoteEdit note = new NoteEdit();
        note.addNote("10.10.2021", "note1", "text","teg1", 1);
        note.updateNote(2, "11.10.2021", "note2", "text","teg1", 1);
        note.deleteNote(3);

    }
}