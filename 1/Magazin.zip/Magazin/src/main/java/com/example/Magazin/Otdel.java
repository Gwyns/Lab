package com.example.Magazin;

import javax.persistence.*;

@Entity
public class Otdel {
    @Id
    private int idOtdel;
    private String name;

    public int getIdOtdel() {
        return idOtdel;
    }

    public void setIdOtdel(int idOtdel) {
        this.idOtdel = idOtdel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
