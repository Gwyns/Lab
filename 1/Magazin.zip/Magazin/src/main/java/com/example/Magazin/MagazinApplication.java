package com.example.Magazin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagazinApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagazinApplication.class, args);
	}

}
