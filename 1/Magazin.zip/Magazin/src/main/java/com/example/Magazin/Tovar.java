package com.example.Magazin;

import javax.persistence.*;

@Entity
public class Tovar {
    @Id
    private int idTovar;
    private String name;
    private int price;
    private int Otdel_idOtdel;

    public int getIdTovar() {
        return idTovar;
    }

    public void setIdTovar(int idTovar) {
        this.idTovar = idTovar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getOtdel_idOtdel() {
        return Otdel_idOtdel;
    }

    public void setOtdel_idOtdel(int otdel_idOtdel) {
        Otdel_idOtdel = otdel_idOtdel;
    }
}
