package com.example.Magazin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagazinApplicationTests {

	@Test
	void contextLoads() {
	}

}
