package com.order.model;

import javax.persistence.*;

@Entity
public class Order {
    private int idorder;
    private int client_idclient;
    private int product_idproduct;
    private String data;
    private String status;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getIdorder() {
        return idorder;
    }

    public void setIdorder(int idorder) {
        this.idorder = idorder;
    }

    public int getClient_idclient() {
        return client_idclient;
    }

    public void setClient_idclient(int client_idclient) {
        this.client_idclient = client_idclient;
    }

    public int getProduct_idproduct() {
        return product_idproduct;
    }

    public void setProduct_idproduct(int product_idproduct) {
        this.product_idproduct = product_idproduct;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
