package com.order.Controller;

import com.order.model.Client;
import com.order.model.Order;
import com.order.model.Product;
import com.order.Service.ClientService;
import com.order.Service.OrderService;
import com.order.Service.ProductService;
import java.util.List;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.*;

@Controller
public class OrderController {

    @Autowired
    private ClientService clientservice;
    @Autowired
    private OrderService orderservice;
    @Autowired
    private ProductService productservice;

    @RequestMapping("/")
    public String viewHomePage(Model model){
        List<Client> listClient = clientservice.listAll();
        model.addAttribute("listClient", listClient);
        List<Order> listOrder = orderservice.listAll();
        model.addAttribute("listOrder", listOrder);
        List<Product> listProduct = productservice.listAll();
        model.addAttribute("listProduct", listProduct);
        return "index";
    }





    @RequestMapping("/newclient")
    public String showNewClientPage(Model model) {
        Client client = new Client();
        model.addAttribute("client", client);
        return "new_client";
    }

    @RequestMapping(value = "/saveclient", method = RequestMethod.POST)
    public String saveClient(@ModelAttribute("client") Client client) {
        clientservice.save(client);
        return "redirect:/";
    }

    @RequestMapping("/editclient/{idclient}")
    public ModelAndView showEditClientPage(@PathVariable(name = "idclient") Integer idclient) {
        ModelAndView mav = new ModelAndView("edit_client");
        Client client = clientservice.get(idclient);
        mav.addObject("client", client);

        return mav;
    }

    @RequestMapping("/deleteclient/{idclient}")
    public String deleteClient(@PathVariable(name = "idclient") Integer idclient) {
        clientservice.delete(idclient);
        return "redirect:/";
    }





    @RequestMapping("/neworder")
    public String showNewOrderPage(Model model) {
        Order order = new Order();
        model.addAttribute("order", order);
        return "new_order";
    }

    @RequestMapping(value = "/saveorder", method = RequestMethod.POST)
    public String saveOrder(@ModelAttribute("order") Order order) {
        orderservice.save(order);
        return "redirect:/";
    }

    @RequestMapping("/editorder/{idorder}")
    public ModelAndView showEditOrderPage(@PathVariable(name = "idorder") Integer idorder) {
        ModelAndView mav = new ModelAndView("edit_order");
        Order order = orderservice.get(idorder);
        mav.addObject("order", order);

        return mav;
    }

    @RequestMapping("/deleteorder/{idorder}")
    public String deleteOrder(@PathVariable(name = "idorder") Integer idorder) {
        orderservice.delete(idorder);
        return "redirect:/";
    }





    @RequestMapping("/newproduct")
    public String showNewProductPage(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "new_product";
    }

    @RequestMapping(value = "/saveproduct", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("product") Product product) {
        productservice.save(product);
        return "redirect:/";
    }

    @RequestMapping("/editproduct/{idproduct}")
    public ModelAndView showEditProductPage(@PathVariable(name = "idproduct") Integer idproduct) {
        ModelAndView mav = new ModelAndView("edit_product");
        Product product = productservice.get(idproduct);
        mav.addObject("product", product);

        return mav;
    }

    @RequestMapping("/deleteproduct/{idproduct}")
    public String deleteProduct(@PathVariable(name = "idproduct") Integer idproduct) {
        productservice.delete(idproduct);
        return "redirect:/";
    }
}
