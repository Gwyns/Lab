package com.order.Service;

import com.order.model.Client;
import com.order.Repository.ClientRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService {
    @Autowired
    private ClientRepository repo;

    public List<Client> listAll() {
        return repo.findAll();
    }

    public void save(Client client) {
        repo.save(client);
    }

    public Client get(Integer idclient) {
        return repo.findById(idclient).get();
    }

    public void delete(Integer idclient) {
        repo.deleteById(idclient);
    }
}
